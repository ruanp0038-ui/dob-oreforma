import { ArrowRight } from "lucide-react";
import { gsap, liteReveal, useGsapScope } from "../lib/anim";
import { IMAGES, WHATSAPP_LINK } from "../config/site";

export default function Intro() {
  const ref = useGsapScope<HTMLElement>(({ reduced }) => {
    if (reduced) {
      liteReveal("[data-intro-line], [data-intro-fade], [data-intro-img]");
      return;
    }
    gsap
      .timeline({ defaults: { ease: "power3.out" } })
      .fromTo(
        "[data-intro-line]",
        { yPercent: 115 },
        {
          yPercent: 0,
          duration: 1,
          stagger: 0.1,
          ease: "power4.out",
          scrollTrigger: { trigger: ref.current, start: "top 72%" },
        }
      )
      .fromTo(
        "[data-intro-fade]",
        { opacity: 0, y: 28 },
        {
          opacity: 1,
          y: 0,
          duration: 0.9,
          stagger: 0.12,
          scrollTrigger: { trigger: ref.current, start: "top 65%" },
        },
        0.2
      )
      .fromTo(
        "[data-intro-img]",
        { clipPath: "inset(0 0 100% 0)" },
        {
          clipPath: "inset(0 0 0% 0)",
          duration: 1.2,
          ease: "power4.inOut",
          scrollTrigger: { trigger: "[data-intro-img]", start: "top 78%" },
        },
        0.1
      );
  });

  return (
    <section
      id="intro"
      ref={ref}
      className="relative bg-ink py-24 md:py-40"
      aria-label="Introdução"
    >
      <div className="mx-auto max-w-[1440px] px-6 md:px-10">
        <div className="grid grid-cols-1 gap-16 lg:grid-cols-12 lg:gap-8">
          <div className="lg:col-span-7">
            <span data-rule aria-hidden="true" className="mb-5 block h-px w-10 origin-left bg-accent" />
            <p data-intro-fade className="kicker mb-8">
              A Do Bão
            </p>
            <h2 className="font-display text-[clamp(2rem,4.6vw,4.2rem)] font-bold uppercase leading-[1.02] tracking-tight text-bone">
              <span className="block overflow-hidden">
                <span data-intro-line className="block">
                  Alto padrão em
                </span>
              </span>
              <span className="block overflow-hidden">
                <span data-intro-line className="block">
                  gestão de obras,
                </span>
              </span>
              <span className="block overflow-hidden">
                <span data-intro-line className="block">
                  construção <em className="font-serif font-normal normal-case italic text-accent">& e reformas.</em>
                </span>
              </span>
            </h2>
          </div>

          <div className="flex flex-col justify-end lg:col-span-4 lg:col-start-9">
            <p data-intro-fade className="text-base leading-relaxed text-bone/75">
              A Do Bão trabalha com especialistas em construção e reforma.
              Sabemos o estresse que envolve uma reforma — e podemos ajudar
              você a planejar, projetar e construir.
            </p>
            <p data-intro-fade className="mt-5 text-base leading-relaxed text-bone/75">
              Da maneira mais rápida e fácil possível, sem perder dinheiro
              com erros ou correr riscos desnecessários.
            </p>
            <a
              data-intro-fade
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              data-cursor-hover
              className="link-underline mt-8 inline-flex items-center gap-3 text-[11px] font-semibold uppercase tracking-widest2 text-accent"
            >
              Começar meu projeto
              <ArrowRight size={14} />
            </a>
          </div>
        </div>

        <div className="mt-20 grid grid-cols-1 gap-8 md:mt-28 lg:grid-cols-12">
          <div className="lg:col-span-5 lg:col-start-2">
            <div className="overflow-hidden">
              <img
                data-intro-img
                src={IMAGES.intro}
                alt="Detalhe de arquitetura moderna em construção de alto padrão"
                loading="lazy"
                decoding="async"
                width={800}
                height={1000}
                className="aspect-[4/5] w-full object-cover transition-transform duration-700 ease-out hover:scale-[1.04]"
              />
            </div>
            <p className="mt-4 text-[11px] uppercase tracking-widest2 text-concrete">
              Imagem demonstrativa
            </p>
          </div>
          <div className="flex flex-col justify-end lg:col-span-4 lg:col-start-8">
            <p data-intro-fade className="font-serif text-2xl italic leading-snug text-bone/90 md:text-3xl">
              “Ajudamos você a planejar, projetar e construir a casa dos seus
              sonhos.”
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
