import { useState } from "react";
import { ArrowUpRight } from "lucide-react";
import { gsap, liteReveal, useGsapScope } from "../lib/anim";
import {
  IMAGES,
  SERVICES_MAIN,
  SERVICES_SPECIALIZED,
  SERVICES_FINISHING,
} from "../config/site";

export default function Services() {
  const [active, setActive] = useState(0);

  const ref = useGsapScope<HTMLElement>(({ reduced }) => {
    if (reduced) {
      liteReveal(
        "[data-svcs-line], [data-svcs-fade], [data-service-row], [data-svc-chip], [data-services-aside]"
      );
      return;
    }
    gsap.fromTo(
      "[data-svcs-line]",
      { yPercent: 115 },
      {
        yPercent: 0,
        duration: 1,
        ease: "power4.out",
        scrollTrigger: { trigger: "[data-svcs-line]", start: "top 88%" },
      }
    );
    gsap.fromTo(
      "[data-svcs-fade]",
      { opacity: 0, y: 22 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        stagger: 0.1,
        ease: "power3.out",
        scrollTrigger: { trigger: "[data-svcs-line]", start: "top 88%" },
      }
    );
    gsap.fromTo(
      "[data-service-row]",
      { opacity: 0, y: 40 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        stagger: 0.09,
        ease: "power3.out",
        scrollTrigger: { trigger: "[data-services-list]", start: "top 75%" },
      }
    );
    gsap.fromTo(
      "[data-svc-title]",
      { yPercent: 115 },
      {
        yPercent: 0,
        duration: 0.9,
        stagger: 0.09,
        ease: "power4.out",
        scrollTrigger: { trigger: "[data-services-list]", start: "top 75%" },
      }
    );
    gsap.fromTo(
      "[data-svc-num]",
      { x: -18, opacity: 0 },
      {
        x: 0,
        opacity: 1,
        duration: 0.7,
        stagger: 0.09,
        ease: "power3.out",
        scrollTrigger: { trigger: "[data-services-list]", start: "top 75%" },
      }
    );
    gsap.fromTo(
      "[data-svc-chip]",
      { opacity: 0, x: -14 },
      {
        opacity: 1,
        x: 0,
        duration: 0.6,
        stagger: 0.05,
        ease: "power3.out",
        scrollTrigger: { trigger: "[data-svc-lists]", start: "top 90%" },
      }
    );
    gsap.fromTo(
      "[data-services-aside]",
      { opacity: 0, y: 30 },
      {
        opacity: 1,
        y: 0,
        duration: 0.9,
        ease: "power3.out",
        scrollTrigger: { trigger: "[data-services-aside]", start: "top 80%" },
      }
    );
  });

  return (
    <section
      id="servicos"
      ref={ref}
      className="relative border-t border-white/5 bg-graphite py-24 md:py-36"
      aria-label="Serviços"
    >
      <div className="mx-auto max-w-[1440px] px-6 md:px-10">
        <div className="mb-16 flex flex-col gap-6 md:mb-20 md:flex-row md:items-end md:justify-between">
          <div>
            <span data-rule aria-hidden="true" className="mb-5 block h-px w-10 origin-left bg-accent" />
            <p data-svcs-fade className="kicker mb-6">Serviços</p>
            <h2 className="font-display text-[clamp(2rem,4.6vw,4.2rem)] font-bold uppercase leading-[1.02] tracking-tight text-bone">
              <span className="block overflow-hidden">
                <span data-svcs-line className="block">O que fazemos</span>
              </span>
            </h2>
          </div>
          <p data-svcs-fade className="max-w-sm text-sm leading-relaxed text-bone/60">
            Da engenharia ao acabamento: uma estrutura completa para planejar,
            executar e entregar a sua obra.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-14 lg:grid-cols-12 lg:gap-12">
          <div data-services-list className="lg:col-span-7">
            <ol className="border-t border-bone/12">
              {SERVICES_MAIN.map((service, i) => (
                <li
                  key={service.title}
                  data-service-row
                  onMouseEnter={() => setActive(i)}
                  onFocus={() => setActive(i)}
                  className="group relative border-b border-bone/12"
                >
                  <a
                    href="#contato"
                    data-cursor-hover
                    className="flex items-center gap-6 py-7 outline-none md:py-9"
                  >
                    <span
                      data-svc-num
                      className="w-8 shrink-0 text-[11px] font-semibold tracking-wider text-concrete transition-colors duration-300 group-hover:text-accent"
                    >
                      0{i + 1}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="block overflow-hidden">
                        <span data-svc-title className="block">
                          <span className="block font-display text-[clamp(1.6rem,3.4vw,3rem)] font-bold uppercase leading-none tracking-tight text-bone transition-transform duration-500 ease-out group-hover:translate-x-3">
                            {service.title}
                          </span>
                        </span>
                      </span>
                      <span className="mt-2 block max-w-md text-sm text-bone/55 opacity-0 transition-all duration-500 group-hover:translate-x-3 group-hover:opacity-100 md:translate-x-0">
                        {service.desc}
                      </span>
                    </span>
                    <ArrowUpRight
                      size={26}
                      aria-hidden="true"
                      className="shrink-0 -translate-x-2 text-accent opacity-0 transition-all duration-500 group-hover:translate-x-0 group-hover:opacity-100"
                    />
                  </a>
                  <span
                    aria-hidden="true"
                    className="absolute bottom-0 left-0 h-px w-full origin-left scale-x-0 bg-accent transition-transform duration-500 ease-out group-hover:scale-x-100"
                  />
                </li>
              ))}
            </ol>

            <div data-svc-lists className="mt-14 grid grid-cols-1 gap-10 sm:grid-cols-2">
              <div>
                <p className="mb-5 text-[11px] font-semibold uppercase tracking-widest2 text-concrete">
                  Serviços especializados
                </p>
                <ul className="flex flex-wrap gap-x-6 gap-y-3">
                  {SERVICES_SPECIALIZED.map((s) => (
                    <li key={s} data-svc-chip className="text-sm text-bone/75">
                      {s}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="mb-5 text-[11px] font-semibold uppercase tracking-widest2 text-concrete">
                  Acabamentos & reparos
                </p>
                <ul className="flex flex-wrap gap-x-6 gap-y-3">
                  {SERVICES_FINISHING.map((s) => (
                    <li key={s} data-svc-chip className="text-sm text-bone/75">
                      {s}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          <div
            data-services-aside
            className="hidden lg:col-span-4 lg:col-start-9 lg:block"
          >
            <div className="relative aspect-[4/5] overflow-hidden">
              {IMAGES.services.map((src, i) => (
                <img
                  key={src}
                  src={src}
                  alt=""
                  aria-hidden="true"
                  loading="lazy"
                  decoding="async"
                  className={`absolute inset-0 h-full w-full object-cover transition-all duration-700 ease-out ${
                    i === active ? "scale-100 opacity-100" : "scale-105 opacity-0"
                  }`}
                />
              ))}
              <div className="absolute inset-0 border border-bone/10" aria-hidden="true" />
              <span className="absolute bottom-5 left-5 bg-ink/70 px-3 py-1.5 text-[10px] font-semibold uppercase tracking-widest2 text-bone backdrop-blur">
                Imagem demonstrativa
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
