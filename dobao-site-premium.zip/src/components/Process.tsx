import { gsap, liteReveal, useGsapScope } from "../lib/anim";
import { PROCESS_STEPS } from "../config/site";

export default function Process() {
  const ref = useGsapScope<HTMLElement>(({ reduced }) => {
    if (reduced) {
      liteReveal("[data-proc-line], [data-proc-fade], [data-process-step]");
      return;
    }

    gsap.fromTo(
      "[data-proc-line]",
      { yPercent: 115 },
      {
        yPercent: 0,
        duration: 1,
        ease: "power4.out",
        scrollTrigger: { trigger: "[data-proc-line]", start: "top 88%" },
      }
    );
    gsap.fromTo(
      "[data-proc-fade]",
      { opacity: 0, y: 22 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: { trigger: "[data-proc-line]", start: "top 88%" },
      }
    );

    gsap.fromTo(
      "[data-process-line]",
      { scaleY: 0 },
      {
        scaleY: 1,
        ease: "none",
        transformOrigin: "top center",
        scrollTrigger: {
          trigger: "[data-process-steps]",
          start: "top 70%",
          end: "bottom 60%",
          scrub: 0.6,
        },
      }
    );

    gsap.utils.toArray<HTMLElement>("[data-process-step]").forEach((step) => {
      const num = step.querySelector("[data-process-num]");
      const content = step.querySelector("[data-process-content]");
      const tl = gsap.timeline({
        defaults: { ease: "power3.out" },
        scrollTrigger: { trigger: step, start: "top 78%" },
      });
      if (num) tl.fromTo(num, { opacity: 0, y: 24 }, { opacity: 1, y: 0, duration: 0.7 });
      if (content)
        tl.fromTo(
          content,
          { opacity: 0, y: 34 },
          { opacity: 1, y: 0, duration: 0.8 },
          0.15
        );
    });
  });

  return (
    <section
      ref={ref}
      className="relative border-t border-white/5 bg-graphite py-24 md:py-36"
      aria-label="Do planejamento à entrega"
    >
      <div className="mx-auto max-w-[1440px] px-6 md:px-10">
        <div className="mb-16 max-w-2xl md:mb-24">
          <span data-rule aria-hidden="true" className="mb-5 block h-px w-10 origin-left bg-accent" />
          <p data-proc-fade className="kicker mb-6">Como trabalhamos</p>
          <h2 className="font-display text-[clamp(2rem,4.6vw,4.2rem)] font-bold uppercase leading-[1.02] tracking-tight text-bone">
            <span className="block overflow-hidden">
              <span data-proc-line className="block">
                Do planejamento{" "}
                <em className="font-serif font-normal normal-case italic text-accent">à</em>{" "}
                entrega
              </span>
            </span>
          </h2>
        </div>

        <ol data-process-steps className="relative ml-2 md:ml-6">
          <div
            aria-hidden="true"
            className="absolute bottom-0 left-0 top-0 w-px bg-bone/10 md:left-0"
          >
            <div
              data-process-line
              className="h-full w-full origin-top bg-accent will-change-transform"
            />
          </div>

          {PROCESS_STEPS.map((step) => (
            <li
              key={step.num}
              data-process-step
              className="relative grid grid-cols-1 gap-3 pb-16 pl-10 last:pb-0 md:grid-cols-12 md:gap-8 md:pl-16 md:pb-20"
            >
              <span
                data-process-num
                aria-hidden="true"
                className="absolute left-0 top-0 hidden -translate-x-1/2 bg-graphite pr-0 text-sm font-semibold tracking-widest text-accent md:block"
              >
                {step.num}
              </span>
              <span
                data-process-num
                aria-hidden="true"
                className="absolute left-0 top-1 -translate-x-1/2 bg-graphite text-[11px] font-semibold text-accent md:hidden"
              >
                {step.num}
              </span>

              <h3
                data-process-content
                className="font-display text-[clamp(1.5rem,3vw,2.6rem)] font-bold uppercase tracking-tight text-bone md:col-span-4"
              >
                {step.title}
              </h3>
              <p
                data-process-content
                className="max-w-md text-sm leading-relaxed text-bone/60 md:col-span-6 md:col-start-6 md:text-base"
              >
                {step.desc}
              </p>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
