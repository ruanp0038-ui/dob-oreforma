import { Zap, ZapOff } from "lucide-react";
import { prefersReducedMotion, setMotionPreference } from "../lib/anim";

export default function MotionToggle() {
  const reduced = prefersReducedMotion();
  const label = reduced ? "Ativar animações" : "Desativar animações";

  const toggle = () => {
    setMotionPreference(!reduced);
    window.location.reload();
  };

  return (
    <button
      type="button"
      onClick={toggle}
      data-cursor-hover
      aria-label={label}
      title={label}
      aria-pressed={!reduced}
      className="group flex h-11 items-center gap-2 border border-bone/15 px-3 text-[10px] font-semibold uppercase tracking-widest2 text-bone/60 transition-all duration-300 hover:border-bone/50 hover:text-bone"
    >
      {reduced ? (
        <ZapOff size={13} className="text-concrete transition-colors group-hover:text-accent" />
      ) : (
        <Zap size={13} className="text-accent" />
      )}
      <span className="hidden sm:inline">Motion</span>
      <span
        aria-hidden="true"
        className={`h-1.5 w-1.5 rounded-full transition-colors duration-300 ${
          reduced ? "bg-bone/25" : "bg-accent"
        }`}
      />
    </button>
  );
}
