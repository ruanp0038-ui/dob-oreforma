import { useLayoutEffect, useRef, useState } from "react";
import { gsap, prefersReducedMotion } from "../lib/anim";
import { LOCATION } from "../config/site";

const WORD = "DO BÃO";

export default function Preloader() {
  const ref = useRef<HTMLDivElement>(null);
  const [gone, setGone] = useState(false);

  useLayoutEffect(() => {
    const panel = ref.current;
    if (!panel) return;
    const reduced = prefersReducedMotion();
    document.body.style.overflow = "hidden";

    const reveal = () => {
      (window as unknown as { __dbPreloaded?: boolean }).__dbPreloaded = true;
      window.dispatchEvent(new Event("preload:done"));
    };

    let tl: gsap.core.Timeline;
    if (reduced) {
      tl = gsap.timeline({
        defaults: { ease: "power1.out" },
        onComplete: () => setGone(true),
      });
      tl.fromTo(
        "[data-pre-char], [data-pre-sub], [data-pre-loc]",
        { autoAlpha: 0 },
        { autoAlpha: 1, duration: 0.4, stagger: 0.04 }
      )
        .fromTo(
          "[data-pre-rule]",
          { scaleX: 0 },
          { scaleX: 1, duration: 0.7, ease: "power1.inOut" }
        )
        .to({}, { duration: 0.35 })
        .call(reveal)
        .to(panel, { autoAlpha: 0, duration: 0.45 });
    } else {
      const chars = gsap.utils.toArray<HTMLElement>("[data-pre-char]", panel);
      tl = gsap.timeline({
        defaults: { ease: "power3.out" },
        onComplete: () => setGone(true),
      });
      tl.fromTo(
        chars,
        {
          opacity: 0,
          x: (i: number) => (i - (chars.length - 1) / 2) * 52,
          scale: 1.7,
          filter: "blur(10px)",
        },
        {
          opacity: 1,
          x: 0,
          scale: 1,
          filter: "blur(0px)",
          duration: 1.05,
          stagger: 0.06,
          ease: "power3.out",
        },
        0.15
      )
        .fromTo(
          "[data-pre-sub]",
          { opacity: 0, y: 14 },
          { opacity: 1, y: 0, duration: 0.7 },
          0.6
        )
        .fromTo(
          "[data-pre-rule]",
          { scaleX: 0 },
          { scaleX: 1, duration: 1.35, ease: "power2.inOut" },
          0.35
        )
        .fromTo("[data-pre-loc]", { opacity: 0 }, { opacity: 1, duration: 0.6 }, 0.95)
        .to(
          "[data-pre-content]",
          { opacity: 0, y: -46, duration: 0.55, ease: "power2.in" },
          "+=0.5"
        )
        .call(reveal)
        .to(panel, { yPercent: -100, duration: 1.05, ease: "power4.inOut" }, "+=0.05");
    }

    return () => {
      tl.kill();
      document.body.style.overflow = "";
    };
  }, []);

  if (gone) return null;

  return (
    <div
      ref={ref}
      role="status"
      aria-label="Carregando o site da Do Bão Reformas & Construção"
      className="fixed inset-0 z-[200] flex items-center justify-center bg-ink"
    >
      <div data-pre-content aria-hidden="true" className="flex flex-col items-center px-6 text-center">
        <h2 className="flex font-display text-[clamp(3.2rem,13vw,9.5rem)] font-extrabold uppercase leading-none tracking-tight text-bone">
          {WORD.split("").map((ch, i) => (
            <span key={i} data-pre-char className="inline-block will-change-transform">
              {ch === " " ? "\u00A0" : ch}
            </span>
          ))}
        </h2>
        <p data-pre-sub className="mt-6 flex items-center gap-4 text-[10px] font-semibold uppercase tracking-widest2 text-concrete md:text-xs">
          <span aria-hidden="true" className="h-px w-8 bg-bone/25" />
          Reformas & Construção
          <span aria-hidden="true" className="h-px w-8 bg-bone/25" />
        </p>
        <span
          data-pre-rule
          aria-hidden="true"
          className="mt-12 h-px w-44 origin-center bg-accent md:w-56"
        />
        <p data-pre-loc className="mt-5 text-[10px] uppercase tracking-widest2 text-bone/40">
          {LOCATION}
        </p>
      </div>
    </div>
  );
}
