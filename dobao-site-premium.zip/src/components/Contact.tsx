import { ArrowRight, MapPin, Phone } from "lucide-react";
import { gsap, liteReveal, useGsapScope } from "../lib/anim";
import { WHATSAPP_LINK, PHONE_DISPLAY, PHONE_HREF, LOCATION } from "../config/site";

export default function Contact() {
  const ref = useGsapScope<HTMLElement>(({ reduced }) => {
    if (reduced) {
      liteReveal("[data-cta-line], [data-cta-fade], [data-cta-info]");
      return;
    }
    gsap
      .timeline({
        defaults: { ease: "power3.out" },
        scrollTrigger: { trigger: ref.current, start: "top 70%" },
      })
      .fromTo(
        "[data-cta-line]",
        { yPercent: 115 },
        { yPercent: 0, duration: 1, stagger: 0.12, ease: "power4.out" }
      )
      .fromTo(
        "[data-cta-fade]",
        { opacity: 0, y: 26 },
        { opacity: 1, y: 0, duration: 0.9, stagger: 0.12 },
        0.25
      );

    gsap.fromTo(
      "[data-cta-glow]",
      { opacity: 0, scale: 0.6 },
      {
        opacity: 1,
        scale: 1,
        duration: 1.6,
        ease: "power2.out",
        scrollTrigger: { trigger: ref.current, start: "top 78%" },
      }
    );
    gsap.fromTo(
      "[data-cta-info]",
      { opacity: 0, y: 18 },
      {
        opacity: 1,
        y: 0,
        duration: 0.7,
        stagger: 0.1,
        ease: "power3.out",
        scrollTrigger: { trigger: "[data-cta-infos]", start: "top 94%" },
      }
    );
  });

  return (
    <section
      id="contato"
      ref={ref}
      className="relative overflow-hidden border-t border-white/5 bg-ink py-28 md:py-44"
      aria-label="Contato"
    >
      <div
        data-cta-glow
        aria-hidden="true"
        className="pointer-events-none absolute -right-40 -top-40 h-[480px] w-[480px] rounded-full bg-accent/10 blur-[140px]"
      />
      <div className="relative mx-auto flex max-w-[1440px] flex-col items-center px-6 text-center md:px-10">
        <span data-rule aria-hidden="true" className="mb-5 block h-px w-10 origin-left bg-accent" />
        <p data-cta-fade className="kicker mb-10">
          Contato
        </p>
        <h2 className="font-display text-[clamp(2.4rem,7vw,6.5rem)] font-extrabold uppercase leading-[0.96] tracking-tight text-bone">
          <span className="block overflow-hidden">
            <span data-cta-line className="block">
              Vamos tirar seu
            </span>
          </span>
          <span className="block overflow-hidden">
            <span data-cta-line className="block">
              projeto <em className="font-serif font-normal normal-case italic text-accent">do papel?</em>
            </span>
          </span>
        </h2>
        <p data-cta-fade className="mt-8 max-w-xl text-base leading-relaxed text-bone/70 md:text-lg">
          Fale com a Do Bão Reformas & Construção e conte o que você precisa.
        </p>

        <div data-cta-fade className="mt-12">
          <a
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            data-cursor-hover
            className="btn-primary group px-10 py-5"
          >
            Solicitar orçamento
            <ArrowRight size={15} className="transition-transform duration-300 group-hover:translate-x-1.5" />
          </a>
        </div>

        <div data-cta-infos className="mt-14 flex flex-col items-center gap-4 text-sm text-bone/60 sm:flex-row sm:gap-10">
          <a
            data-cta-info
            href={PHONE_HREF}
            data-cursor-hover
            className="link-underline flex items-center gap-2 transition-colors hover:text-bone"
          >
            <Phone size={14} className="text-accent" aria-hidden="true" />
            {PHONE_DISPLAY}
          </a>
          <span data-cta-info className="hidden h-4 w-px bg-bone/20 sm:block" aria-hidden="true" />
          <span data-cta-info className="flex items-center gap-2">
            <MapPin size={14} className="text-accent" aria-hidden="true" />
            {LOCATION}
          </span>
        </div>
      </div>
    </section>
  );
}
