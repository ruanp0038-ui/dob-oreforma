import { useLayoutEffect } from "react";
import { gsap, prefersReducedMotion } from "../lib/anim";

const STRENGTH = 0.18;
const MAX = 10;

export default function MagneticButtons() {
  useLayoutEffect(() => {
    if (
      prefersReducedMotion() ||
      !window.matchMedia("(pointer: fine)").matches
    )
      return;

    const cleanups: Array<() => void> = [];
    document
      .querySelectorAll<HTMLElement>(".btn-primary, [data-magnetic]")
      .forEach((btn) => {
        gsap.set(btn, { x: 0, y: 0 });
        const xTo = gsap.quickTo(btn, "x", { duration: 0.4, ease: "power3.out" });
        const yTo = gsap.quickTo(btn, "y", { duration: 0.4, ease: "power3.out" });

        const onMove = (e: MouseEvent) => {
          const r = btn.getBoundingClientRect();
          const relX = e.clientX - (r.left + r.width / 2);
          const relY = e.clientY - (r.top + r.height / 2);
          xTo(gsap.utils.clamp(-MAX, MAX, relX * STRENGTH));
          yTo(gsap.utils.clamp(-MAX, MAX * 0.7, relY * STRENGTH));
        };
        const onLeave = () => {
          gsap.to(btn, { x: 0, y: 0, duration: 0.8, ease: "elastic.out(1, 0.4)" });
        };

        btn.addEventListener("mousemove", onMove);
        btn.addEventListener("mouseleave", onLeave);
        cleanups.push(() => {
          btn.removeEventListener("mousemove", onMove);
          btn.removeEventListener("mouseleave", onLeave);
          gsap.set(btn, { x: 0, y: 0 });
        });
      });

    return () => cleanups.forEach((fn) => fn());
  }, []);

  return null;
}
