﻿import { gsap, liteReveal, useGsapScope } from "../lib/anim";
import { IMAGES } from "../config/site";

export default function About() {
  const ref = useGsapScope<HTMLElement>(({ reduced }) => {
    if (reduced) {
      liteReveal("[data-about-line], [data-about-fade], [data-about-chip]");
      return;
    }
    gsap
      .timeline({
        defaults: { ease: "power3.out" },
        scrollTrigger: { trigger: ref.current, start: "top 70%" },
      })
      .fromTo(
        "[data-about-line]",
        { yPercent: 115 },
        { yPercent: 0, duration: 1, stagger: 0.12, ease: "power4.out" }
      )
      .fromTo(
        "[data-about-fade]",
        { opacity: 0, y: 26 },
        { opacity: 1, y: 0, duration: 0.9, stagger: 0.1 },
        0.2
      );

    gsap.utils.toArray<HTMLElement>("[data-about-clip]").forEach((el) => {
      gsap.fromTo(
        el,
        { clipPath: "inset(0 0 100% 0)" },
        {
          clipPath: "inset(0 0 0% 0)",
          duration: 1.2,
          ease: "power4.inOut",
          scrollTrigger: { trigger: el, start: "top 86%" },
        }
      );
    });

    gsap.fromTo(
      "[data-about-img-1]",
      { yPercent: -5, scale: 1.15 },
      {
        yPercent: 5,
        scale: 1.15,
        ease: "none",
        scrollTrigger: { trigger: "[data-about-imgs]", start: "top bottom", end: "bottom top", scrub: true },
      }
    );
    gsap.fromTo(
      "[data-about-img-2]",
      { yPercent: 5, scale: 1.15 },
      {
        yPercent: -5,
        scale: 1.15,
        ease: "none",
        scrollTrigger: { trigger: "[data-about-imgs]", start: "top bottom", end: "bottom top", scrub: true },
      }
    );
    gsap.fromTo(
      "[data-about-chip]",
      { opacity: 0, x: -14 },
      {
        opacity: 1,
        x: 0,
        duration: 0.55,
        stagger: 0.06,
        ease: "power3.out",
        scrollTrigger: { trigger: "[data-about-list]", start: "top 92%" },
      }
    );
  });

  return (
    <section
      id="sobre"
      ref={ref}
      className="relative border-t border-white/5 bg-ink py-24 md:py-36"
      aria-label="Sobre a empresa"
    >
      <div className="mx-auto max-w-[1440px] px-6 md:px-10">
        <div className="grid grid-cols-1 gap-16 lg:grid-cols-12 lg:gap-8">
          <div className="lg:col-span-7">
            <span data-rule aria-hidden="true" className="mb-5 block h-px w-10 origin-left bg-accent" />
            <p data-about-fade className="kicker mb-8">
              Sobre a Do BÃ£o
            </p>
            <h2 className="font-display text-[clamp(2rem,4.6vw,4.2rem)] font-bold uppercase leading-[1.02] tracking-tight text-bone">
              <span className="block overflow-hidden">
                <span data-about-line className="block">
                  Construir Ã© mais
                </span>
              </span>
              <span className="block overflow-hidden">
                <span data-about-line className="block">
                  do que executar.
                </span>
              </span>
              <span className="block overflow-hidden">
                <span data-about-line className="block">
                  Ã‰ realizar{" "}
                  <em className="font-serif font-normal normal-case italic text-accent">um projeto.</em>
                </span>
              </span>
            </h2>
          </div>

          <div className="flex flex-col justify-end lg:col-span-4 lg:col-start-9">
            <p data-about-fade className="text-base leading-relaxed text-bone/75">
              A Do BÃ£o Reformas & ConstruÃ§Ã£o Ã© uma empresa especializada em
              construÃ§Ã£o, reformas e gestÃ£o de obras â€” com projetos e serviÃ§os
              especializados para transformar a sua casa.
            </p>
            <p data-about-fade className="mt-5 text-base leading-relaxed text-bone/75">
              Entendemos o estresse envolvido em uma reforma. Por isso,
              ajudamos o cliente a planejar, projetar e construir da maneira
              mais rÃ¡pida e fÃ¡cil possÃ­vel.
            </p>
            <ul data-about-list className="mt-8 flex flex-wrap gap-x-5 gap-y-2 text-[11px] font-semibold uppercase tracking-widest2 text-bone/55">
              {["Construção", "Reformas", "Gestão de obras", "Projetos", "Serviços especializados"].map(
                (item) => (
                  <li key={item} data-about-chip className="flex items-center gap-5">
                    <span aria-hidden="true" className="inline-block h-1 w-1 rounded-full bg-accent" />
                    {item}
                  </li>
                )
              )}
            </ul>
          </div>
        </div>

        <div data-about-imgs className="mt-20 grid grid-cols-2 gap-6 md:mt-28 md:gap-10 lg:grid-cols-12">
          <div data-about-clip className="overflow-hidden lg:col-span-5 lg:col-start-2">
            <img
              data-about-img-1
              src={IMAGES.about1}
              alt="Ambiente em processo de reforma com acabamento cuidadoso â€” imagem demonstrativa"
              loading="lazy"
              decoding="async"
              width={800}
              height={1000}
              className="aspect-[4/5] w-full object-cover will-change-transform"
            />
          </div>
          <div data-about-clip className="overflow-hidden md:mt-24 lg:col-span-4 lg:col-start-8">
            <img
              data-about-img-2
              src={IMAGES.about2}
              alt="Interior de alto padrÃ£o apÃ³s reforma â€” imagem demonstrativa"
              loading="lazy"
              decoding="async"
              width={700}
              height={900}
              className="aspect-[3/4] w-full object-cover will-change-transform"
            />
          </div>
        </div>
        <p className="mt-4 text-[11px] uppercase tracking-widest2 text-concrete">
          Imagens demonstrativas
        </p>
      </div>
    </section>
  );
}
