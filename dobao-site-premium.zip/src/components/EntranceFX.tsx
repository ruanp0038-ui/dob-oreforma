import { useLayoutEffect } from "react";
import { gsap, prefersReducedMotion } from "../lib/anim";

export default function EntranceFX() {
  useLayoutEffect(() => {
    const reduced = prefersReducedMotion();
    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>("[data-rule]").forEach((el) => {
        if (reduced) {
          gsap.fromTo(
            el,
            { autoAlpha: 0 },
            {
              autoAlpha: 1,
              duration: 0.5,
              ease: "power1.out",
              scrollTrigger: { trigger: el, start: "top 92%" },
            }
          );
        } else {
          gsap.fromTo(
            el,
            { scaleX: 0 },
            {
              scaleX: 1,
              duration: 0.9,
              ease: "power3.out",
              scrollTrigger: { trigger: el, start: "top 88%" },
            }
          );
        }
      });
    });
    return () => ctx.revert();
  }, []);

  return null;
}
