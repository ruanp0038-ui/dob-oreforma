import { ArrowDown, ArrowRight } from "lucide-react";
import { gsap, useGsapScope } from "../lib/anim";
import { IMAGES, WHATSAPP_LINK, LOCATION } from "../config/site";

const KICKER = "Construção • Reforma • Gestão de Obras";
const SUBTITLE =
  "Construção e reformas de alto padrão, com planejamento, gestão e atenção em cada detalhe.";

export default function Hero() {
  const ref = useGsapScope<HTMLElement>(({ reduced }) => {
    const startIntro = () => {
      if (reduced) {
        gsap.fromTo(
          "[data-hero-kicker], [data-hero-line], [data-hero-word], [data-hero-cta], [data-hero-baritem]",
          { autoAlpha: 0 },
          { autoAlpha: 1, duration: 0.55, stagger: 0.09, ease: "power1.out" }
        );
        return;
      }

      const tl = gsap.timeline({ defaults: { ease: "power3.out" } });
      tl.fromTo(
      "[data-hero-media]",
      { clipPath: "inset(0 0 100% 0)" },
      { clipPath: "inset(0 0 0% 0)", duration: 1.5, ease: "power4.inOut" },
      0
    )
      .fromTo(
        "[data-hero-img]",
        { scale: 1.15 },
        { scale: 1, duration: 2.4, ease: "power2.out" },
        0
      )
      .fromTo("[data-hero-overlay]", { opacity: 0 }, { opacity: 1, duration: 1.2 }, 0.2)
      .fromTo(
        "[data-hero-ch]",
        { yPercent: 120, opacity: 0 },
        { yPercent: 0, opacity: 1, duration: 0.7, stagger: 0.02, ease: "power4.out" },
        0.5
      )
      .fromTo(
        "[data-hero-line]",
        { yPercent: 115 },
        { yPercent: 0, duration: 1.1, stagger: 0.14, ease: "power4.out" },
        0.7
      )
      .fromTo(
        "[data-hero-word]",
        { y: 26, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.8, stagger: 0.055 },
        1.15
      )
      .fromTo(
        "[data-hero-cta]",
        { y: 26, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.8, stagger: 0.12 },
        1.35
      )
      .fromTo(
        "[data-hero-rule]",
        { scaleX: 0 },
        { scaleX: 1, duration: 1, ease: "power3.inOut" },
        1.5
      )
      .fromTo(
        "[data-hero-baritem]",
        { opacity: 0 },
        { opacity: 1, duration: 0.8, stagger: 0.12 },
        1.6
      );

    };

    if ((window as unknown as { __dbPreloaded?: boolean }).__dbPreloaded) {
      startIntro();
    } else {
      window.addEventListener("preload:done", startIntro, { once: true });
    }

    if (!reduced) {
      gsap.to("[data-hero-img]", {
        yPercent: 8,
        ease: "none",
        scrollTrigger: {
          trigger: ref.current,
          start: "top top",
          end: "bottom top",
          scrub: true,
        },
      });
    }
  });

  return (
    <section
      id="inicio"
      ref={ref}
      className="relative flex min-h-[100svh] flex-col overflow-hidden"
      aria-label="Apresentação"
    >
      <div data-hero-media className="absolute inset-0 overflow-hidden" aria-hidden="true">
        <div className="absolute inset-x-0 -top-[10%] h-[120%]">
          <img
            src={IMAGES.hero}
            alt=""
            data-hero-img
            fetchPriority="high"
            decoding="async"
            className="h-full w-full object-cover will-change-transform"
          />
        </div>
      </div>
      <div
        data-hero-overlay
        aria-hidden="true"
        className="absolute inset-0 bg-gradient-to-b from-ink/80 via-ink/45 to-ink/90"
      />
      <div aria-hidden="true" className="absolute inset-0 bg-ink/25" />

      <div className="relative z-10 mx-auto flex w-full max-w-[1440px] flex-1 flex-col justify-end px-6 pb-14 pt-32 md:px-10 md:pb-20">
        <p data-hero-kicker aria-label={KICKER} className="kicker mb-8">
          {KICKER.split("").map((ch, i) => (
            <span
              key={i}
              data-hero-ch
              aria-hidden="true"
              className="inline-block will-change-transform"
            >
              {ch === " " ? "\u00A0" : ch}
            </span>
          ))}
        </p>

        <h1 className="font-display font-extrabold uppercase leading-[0.94] tracking-tight">
          <span className="block overflow-hidden">
            <span data-hero-line className="block text-[clamp(2.9rem,9vw,8.5rem)]">
              Transformando casas
            </span>
          </span>
          <span className="block overflow-hidden">
            <span data-hero-line className="block text-[clamp(2.9rem,9vw,8.5rem)]">
              em{" "}
              <em className="font-serif font-normal normal-case italic tracking-normal text-accent">
                sonhos.
              </em>
            </span>
          </span>
        </h1>

        <div className="mt-10 flex flex-col gap-10 md:mt-14 md:flex-row md:items-end md:justify-between">
          <p className="max-w-xl text-base leading-relaxed text-bone/80 md:text-lg">
            {SUBTITLE.split(" ").map((word, i, arr) => (
              <span
                key={i}
                data-hero-word
                className="inline-block will-change-transform"
              >
                {word}
                {i < arr.length - 1 ? "\u00A0" : ""}
              </span>
            ))}
          </p>

          <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
            <a
              data-hero-cta
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              data-cursor-hover
              className="btn-primary group"
            >
              Solicitar orçamento
              <ArrowRight
                size={14}
                className="transition-transform duration-300 group-hover:translate-x-1.5"
              />
            </a>
            <a data-hero-cta href="#servicos" data-cursor-hover className="btn-ghost">
              Conhecer nossos serviços
            </a>
          </div>
        </div>

        <div className="relative mt-14 md:mt-16">
          <span
            data-hero-rule
            aria-hidden="true"
            className="absolute left-0 top-0 h-px w-full origin-left bg-bone/15"
          />
          <div className="flex items-center justify-between pt-6 text-[11px] font-semibold uppercase tracking-widest2 text-bone/60">
            <span data-hero-baritem className="flex items-center gap-2">
              <span
                aria-hidden="true"
                className="inline-block h-1.5 w-1.5 rounded-full bg-accent"
              />
              {LOCATION}
            </span>
            <a
              data-hero-baritem
              href="#intro"
              aria-label="Rolar para o conteúdo"
              data-cursor-hover
              className="flex items-center gap-2 transition-colors hover:text-bone"
            >
              Role para explorar
              <ArrowDown size={14} className="animate-bounce" aria-hidden="true" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
