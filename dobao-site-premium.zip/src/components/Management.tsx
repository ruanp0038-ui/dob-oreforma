import { ArrowRight } from "lucide-react";
import { gsap, liteReveal, useGsapScope } from "../lib/anim";
import { IMAGES, WHATSAPP_LINK } from "../config/site";

export default function Management() {
  const ref = useGsapScope<HTMLElement>(({ reduced }) => {
    if (reduced) {
      liteReveal("[data-mgmt-line], [data-mgmt-fade]");
      return;
    }
    const tl = gsap.timeline({
      defaults: { ease: "power3.out" },
      scrollTrigger: { trigger: ref.current, start: "top 70%" },
    });
    tl.fromTo(
      "[data-mgmt-line]",
      { yPercent: 115 },
      { yPercent: 0, duration: 1, stagger: 0.12, ease: "power4.out" }
    ).fromTo(
      "[data-mgmt-fade]",
      { opacity: 0, y: 26 },
      { opacity: 1, y: 0, duration: 0.9, stagger: 0.12 },
      0.25
    );

    if (!reduced) {
      gsap.fromTo(
        "[data-mgmt-img]",
        { yPercent: -6, scale: 1.15 },
        {
          yPercent: 6,
          scale: 1.15,
          ease: "none",
          scrollTrigger: {
            trigger: "[data-mgmt-img]",
            start: "top bottom",
            end: "bottom top",
            scrub: true,
          },
        }
      );
      gsap.fromTo(
        "[data-mgmt-img-wrap]",
        { clipPath: "inset(12% 0 12% 0)" },
        {
          clipPath: "inset(0% 0 0% 0)",
          duration: 1.4,
          ease: "power4.inOut",
          scrollTrigger: { trigger: "[data-mgmt-img-wrap]", start: "top 80%" },
        }
      );
    }
  });

  return (
    <section
      ref={ref}
      className="relative border-t border-white/5 bg-ink py-24 md:py-36"
      aria-label="Gestão de obras"
    >
      <div className="mx-auto grid max-w-[1440px] grid-cols-1 items-center gap-14 px-6 md:px-10 lg:grid-cols-12 lg:gap-16">
        <div className="lg:col-span-5">
          <span data-rule aria-hidden="true" className="mb-5 block h-px w-10 origin-left bg-accent" />
          <p data-mgmt-fade className="kicker mb-6">
            Gestão de Obras
          </p>
          <h2 className="font-display text-[clamp(2.4rem,5.5vw,5rem)] font-extrabold uppercase leading-[0.98] tracking-tight text-bone">
            <span className="block overflow-hidden">
              <span data-mgmt-line className="block">
                Sua obra.
              </span>
            </span>
            <span className="block overflow-hidden">
              <span data-mgmt-line className="block">
                <em className="font-serif font-normal normal-case italic text-accent">Nossa</em> gestão.
              </span>
            </span>
          </h2>
          <p data-mgmt-fade className="mt-8 max-w-md text-base leading-relaxed text-bone/75">
            Planejamento, organização e acompanhamento para tornar o processo
            de construção e reforma mais claro e eficiente.
          </p>
          <a
            data-mgmt-fade
            href={WHATSAPP_LINK}
            target="_blank"
            rel="noopener noreferrer"
            data-cursor-hover
            className="btn-ghost group mt-10"
          >
            Falar com a equipe
            <ArrowRight size={14} className="transition-transform duration-300 group-hover:translate-x-1.5" />
          </a>
        </div>

        <div className="lg:col-span-6 lg:col-start-7">
          <div data-mgmt-img-wrap className="overflow-hidden">
            <img
              data-mgmt-img
              src={IMAGES.management}
              alt="Obra de construção acompanhada por gestão profissional"
              loading="lazy"
              decoding="async"
              width={1100}
              height={820}
              className="aspect-[4/3] w-full object-cover will-change-transform"
            />
          </div>
          <p className="mt-4 text-[11px] uppercase tracking-widest2 text-concrete">
            Imagem demonstrativa
          </p>
        </div>
      </div>
    </section>
  );
}
