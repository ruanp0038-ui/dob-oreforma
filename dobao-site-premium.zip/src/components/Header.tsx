import { useEffect, useLayoutEffect, useRef, useState } from "react";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { gsap, prefersReducedMotion } from "../lib/anim";
import MotionToggle from "./MotionToggle";
import { NAV_ITEMS, WHATSAPP_LINK, PHONE_DISPLAY } from "../config/site";

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <a href="#inicio" aria-label="Do Bão Reformas & Construção — início" data-cursor-hover>
      <span
        className={`block font-display font-extrabold uppercase leading-none tracking-tight transition-all duration-300 ${
          compact ? "text-lg" : "text-xl"
        }`}
      >
        Do Bão
      </span>
      <span className="mt-1 block text-[9px] font-medium uppercase tracking-widest2 text-concrete">
        Reformas & Construção
      </span>
    </a>
  );
}

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const barRef = useRef<HTMLDivElement>(null);
  const tlRef = useRef<gsap.core.Timeline | null>(null);

  useLayoutEffect(() => {
    if (prefersReducedMotion() || !barRef.current) return;
    gsap.fromTo(
      barRef.current,
      { y: -28, opacity: 0 },
      { y: 0, opacity: 1, duration: 1, ease: "power3.out", delay: 0.15 }
    );
  }, []);

  useEffect(() => {
    let raf = 0;
    const onScroll = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => setScrolled(window.scrollY > 40));
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => {
      window.removeEventListener("scroll", onScroll);
      cancelAnimationFrame(raf);
    };
  }, []);

  useLayoutEffect(() => {
    const el = menuRef.current;
    if (!el) return;
    const reduced = prefersReducedMotion();
    gsap.set(el, { visibility: "hidden" });
    const tl = gsap.timeline({ paused: true, defaults: { ease: "power3.out" } });
    if (reduced) {
      tl.set(el, { visibility: "visible" });
    } else {
      tl.set(el, { visibility: "visible" })
        .fromTo(
          el,
          { clipPath: "inset(0 0 100% 0)" },
          { clipPath: "inset(0 0 0% 0)", duration: 0.7, ease: "power4.inOut" }
        )
        .fromTo(
          el.querySelectorAll("[data-menu-item]"),
          { y: 42, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.6, stagger: 0.06 },
          "-=0.25"
        );
    }
    tl.eventCallback("onReverseComplete", () =>
      gsap.set(el, { visibility: "hidden" })
    );
    tlRef.current = tl;
    return () => {
      tl.kill();
    };
  }, []);

  useEffect(() => {
    const tl = tlRef.current;
    if (!tl) return;
    if (open) tl.play();
    else tl.reverse();
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const close = () => setOpen(false);

  return (
    <>
      <header
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
          scrolled
            ? "border-b border-white/5 bg-ink/80 py-3 backdrop-blur-xl"
            : "bg-transparent py-6"
        }`}
      >
        <div
          ref={barRef}
          className="mx-auto flex max-w-[1440px] items-center justify-between px-6 md:px-10"
        >
          <Logo compact={scrolled} />
          <nav aria-label="Navegação principal" className="hidden items-center gap-9 lg:flex">
            {NAV_ITEMS.map((item) => (
              <a
                key={item.href}
                href={item.href}
                data-cursor-hover
                className="link-underline text-[11px] font-semibold uppercase tracking-widest2 text-bone/80 transition-colors hover:text-bone"
              >
                {item.label}
              </a>
            ))}
          </nav>
          <div className="flex items-center gap-4">
            <MotionToggle />
            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              data-cursor-hover
              data-magnetic
              className="group hidden items-center gap-2 border border-bone/25 px-6 py-3 text-[11px] font-semibold uppercase tracking-widest2 transition-all duration-300 hover:-translate-y-0.5 hover:border-accent hover:bg-accent hover:text-white md:inline-flex"
            >
              Solicitar orçamento
              <ArrowUpRight
                size={14}
                className="transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
              />
            </a>
            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-label={open ? "Fechar menu" : "Abrir menu"}
              data-cursor-hover
              className="flex h-11 w-11 items-center justify-center border border-bone/20 text-bone transition-colors hover:border-bone/60 lg:hidden"
            >
              {open ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </header>

      <div
        ref={menuRef}
        className="fixed inset-0 z-40 flex flex-col bg-ink lg:hidden"
        role="dialog"
        aria-modal="true"
        aria-label="Menu"
      >
        <div className="flex flex-1 flex-col justify-end px-6 pb-16 pt-28">
          <nav aria-label="Menu mobile" className="flex flex-col gap-2">
            {NAV_ITEMS.map((item, i) => (
              <a
                key={item.href}
                href={item.href}
                onClick={close}
                data-menu-item
                data-cursor-hover
                className="group flex items-baseline gap-4 border-b border-white/8 py-5"
              >
                <span className="text-[11px] font-medium text-accent">
                  0{i + 1}
                </span>
                <span className="font-display text-4xl font-bold uppercase tracking-tight text-bone transition-transform duration-300 group-hover:translate-x-2">
                  {item.label}
                </span>
              </a>
            ))}
          </nav>
          <div data-menu-item className="mt-12 flex flex-col gap-6">
            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-primary w-full"
            >
              Solicitar orçamento
              <ArrowUpRight size={14} />
            </a>
            <a
              href="tel:+5516991656398"
              className="text-sm text-concrete"
            >
              {PHONE_DISPLAY}
            </a>
          </div>
        </div>
      </div>
    </>
  );
}
