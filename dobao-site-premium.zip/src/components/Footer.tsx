import { ArrowUpRight, Instagram, Facebook, Youtube } from "lucide-react";
import { gsap, liteReveal, useGsapScope } from "../lib/anim";
import {
  NAV_ITEMS,
  WHATSAPP_LINK,
  PHONE_DISPLAY,
  PHONE_HREF,
  LOCATION,
  SOCIALS,
} from "../config/site";

const SOCIAL_ICONS = { Instagram, Facebook, YouTube: Youtube } as const;

export default function Footer() {
  const ref = useGsapScope<HTMLElement>(({ reduced }) => {
    if (reduced) {
      liteReveal("[data-footer-item], [data-footer-mark]", { start: "top 96%" });
      return;
    }
    gsap.fromTo(
      "[data-footer-item]",
      { opacity: 0, y: 36 },
      {
        opacity: 1,
        y: 0,
        duration: 0.9,
        stagger: 0.12,
        ease: "power3.out",
        scrollTrigger: { trigger: ref.current, start: "top 82%" },
      }
    );
    gsap.fromTo(
      "[data-footer-mark]",
      { yPercent: 60, opacity: 0 },
      {
        yPercent: 0,
        opacity: 1,
        duration: 1.3,
        ease: "power4.out",
        scrollTrigger: { trigger: "[data-footer-mark]", start: "top 98%" },
      }
    );
  });

  return (
    <footer ref={ref} className="border-t border-white/5 bg-graphite" role="contentinfo">
      <div className="mx-auto max-w-[1440px] px-6 pb-10 pt-20 md:px-10 md:pt-28">
        <div className="grid grid-cols-1 gap-14 md:grid-cols-12">
          <div data-footer-item className="md:col-span-5">
            <p className="font-display text-2xl font-extrabold uppercase leading-none tracking-tight text-bone">
              Do Bão
            </p>
            <p className="mt-2 text-[9px] font-medium uppercase tracking-widest2 text-concrete">
              Reformas & Construção
            </p>
            <p className="mt-8 max-w-sm text-sm leading-relaxed text-bone/55">
              Construção, reformas, projetos e gestão de obras de alto padrão
              em Ribeirão Preto.
            </p>
          </div>

          <nav aria-label="Navegação do rodapé" data-footer-item className="md:col-span-2 md:col-start-7">
            <p className="mb-6 text-[11px] font-semibold uppercase tracking-widest2 text-concrete">
              Navegação
            </p>
            <ul className="flex flex-col gap-3">
              {NAV_ITEMS.map((item) => (
                <li key={item.href}>
                  <a
                    href={item.href}
                    data-cursor-hover
                    className="link-underline text-sm text-bone/70 transition-colors hover:text-bone"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div data-footer-item className="md:col-span-3 md:col-start-10">
            <p className="mb-6 text-[11px] font-semibold uppercase tracking-widest2 text-concrete">
              Contato
            </p>
            <ul className="flex flex-col gap-3 text-sm text-bone/70">
              <li>
                <a
                  href={PHONE_HREF}
                  data-cursor-hover
                  className="link-underline transition-colors hover:text-bone"
                >
                  {PHONE_DISPLAY}
                </a>
              </li>
              <li>{LOCATION}</li>
            </ul>
            <a
              href={WHATSAPP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              data-cursor-hover
              data-magnetic
              className="group mt-8 inline-flex items-center gap-2 border border-bone/25 px-6 py-3 text-[11px] font-semibold uppercase tracking-widest2 text-bone transition-all duration-300 hover:-translate-y-0.5 hover:border-accent hover:bg-accent hover:text-white"
            >
              Solicitar orçamento
              <ArrowUpRight
                size={14}
                className="transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5"
              />
            </a>
          </div>
        </div>

        <div
          aria-hidden="true"
          className="pointer-events-none mt-16 select-none overflow-hidden md:mt-24"
        >
          <p
            data-footer-mark
            className="font-display text-[clamp(4rem,15vw,13rem)] font-extrabold uppercase leading-[0.8] tracking-tight text-bone/[0.05]"
          >
            Do Bão
          </p>
        </div>

        <div data-footer-item className="mt-10 flex flex-col items-start justify-between gap-6 border-t border-bone/10 pt-8 sm:flex-row sm:items-center">
          <p className="text-xs text-concrete">
            © 2026 Do Bão Reformas & Construção. Todos os direitos reservados.
          </p>
          <ul className="flex items-center gap-3" aria-label="Redes sociais">
            {SOCIALS.map((social) => {
              const Icon = SOCIAL_ICONS[social.label as keyof typeof SOCIAL_ICONS];
              return (
                <li key={social.label}>
                  <a
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={social.label}
                    data-cursor-hover
                    className="flex h-10 w-10 items-center justify-center border border-bone/15 text-bone/70 transition-all duration-300 hover:-translate-y-0.5 hover:border-accent hover:text-accent"
                  >
                    <Icon size={16} />
                  </a>
                </li>
              );
            })}
          </ul>
        </div>
      </div>
    </footer>
  );
}
