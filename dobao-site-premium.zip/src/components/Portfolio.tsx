import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowLeft, ArrowRight, X, ZoomIn } from "lucide-react";
import { gsap, liteReveal, useGsapScope, prefersReducedMotion } from "../lib/anim";
import { IMAGES } from "../config/site";

const LAYOUT = [
  "md:col-span-7 md:row-span-2",
  "md:col-span-4 md:col-start-9 md:mt-24",
  "md:col-span-4 md:col-start-2",
  "md:col-span-5 md:col-start-8 md:mt-16",
  "md:col-span-5 md:col-start-2 md:-mt-10",
  "md:col-span-10 md:col-start-2",
];

export default function Portfolio() {
  const [lightbox, setLightbox] = useState<number | null>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const figRef = useRef<HTMLDivElement>(null);
  const dirRef = useRef<1 | -1>(1);
  const openedRef = useRef(false);

  const ref = useGsapScope<HTMLElement>(({ reduced }) => {
    if (reduced) {
      liteReveal("[data-port-line], [data-port-fade], [data-gallery-item]");
      return;
    }
    gsap.fromTo(
      "[data-port-line]",
      { yPercent: 115 },
      {
        yPercent: 0,
        duration: 1,
        ease: "power4.out",
        scrollTrigger: { trigger: "[data-port-line]", start: "top 88%" },
      }
    );
    gsap.fromTo(
      "[data-port-fade]",
      { opacity: 0, y: 22 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        stagger: 0.1,
        ease: "power3.out",
        scrollTrigger: { trigger: "[data-port-line]", start: "top 88%" },
      }
    );
    gsap.utils.toArray<HTMLElement>("[data-gallery-item]").forEach((el, i) => {
      const clip = el.querySelector("[data-gallery-clip]");
      const cap = el.querySelector("[data-gallery-cap]");
      if (clip) {
        gsap.fromTo(
          clip,
          { clipPath: "inset(0 0 100% 0)" },
          {
            clipPath: "inset(0 0 0% 0)",
            duration: 1.1,
            ease: "power4.inOut",
            delay: (i % 3) * 0.06,
            scrollTrigger: { trigger: el, start: "top 88%" },
          }
        );
      }
      if (cap) {
        gsap.fromTo(
          cap,
          { opacity: 0, y: 14 },
          {
            opacity: 1,
            y: 0,
            duration: 0.7,
            delay: 0.35,
            ease: "power3.out",
            scrollTrigger: { trigger: el, start: "top 88%" },
          }
        );
      }
      gsap.fromTo(
        el,
        { opacity: 0, y: 60 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          ease: "power3.out",
          delay: (i % 3) * 0.08,
          scrollTrigger: { trigger: el, start: "top 88%" },
        }
      );
      gsap.to(el.querySelector("[data-gallery-img]"), {
        yPercent: -5,
        ease: "none",
        scrollTrigger: { trigger: el, start: "top bottom", end: "bottom top", scrub: true },
      });
    });
  });

  const closeLightbox = useCallback(() => {
    const overlay = overlayRef.current;
    if (!overlay) return setLightbox(null);
    if (prefersReducedMotion()) return setLightbox(null);
    gsap.to(overlay, {
      opacity: 0,
      duration: 0.35,
      ease: "power2.in",
      onComplete: () => setLightbox(null),
    });
  }, []);

  const openLightbox = useCallback(
    (index: number) => {
      setLightbox(index);
    },
    []
  );

  const step = useCallback(
    (dir: 1 | -1) => {
      dirRef.current = dir;
      setLightbox((cur) =>
        cur === null ? cur : (cur + dir + IMAGES.gallery.length) % IMAGES.gallery.length
      );
    },
    []
  );

  useEffect(() => {
    if (lightbox === null) return;
    document.body.style.overflow = "hidden";
    openedRef.current = true;
    const overlay = overlayRef.current;
    if (overlay && !prefersReducedMotion()) {
      gsap.fromTo(
        overlay,
        { opacity: 0 },
        { opacity: 1, duration: 0.4, ease: "power2.out" }
      );
      if (figRef.current) {
        gsap.fromTo(
          figRef.current,
          { clipPath: "inset(14% 8% 14% 8%)", scale: 0.96 },
          { clipPath: "inset(0% 0% 0% 0%)", scale: 1, duration: 0.65, ease: "power4.out" }
        );
      }
    }
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeLightbox();
      if (e.key === "ArrowRight") step(1);
      if (e.key === "ArrowLeft") step(-1);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = "";
      window.removeEventListener("keydown", onKey);
    };
  }, [lightbox === null, closeLightbox, step]);

  useEffect(() => {
    if (lightbox === null || prefersReducedMotion() || !figRef.current) return;
    if (openedRef.current) {
      openedRef.current = false;
      return;
    }
    gsap.fromTo(
      figRef.current,
      { x: dirRef.current * 56, opacity: 0 },
      { x: 0, opacity: 1, duration: 0.55, ease: "power3.out" }
    );
  }, [lightbox]);

  const current = lightbox !== null ? IMAGES.gallery[lightbox] : null;

  return (
    <section
      id="projetos"
      ref={ref}
      className="relative border-t border-white/5 bg-ink py-24 md:py-36"
      aria-label="Projetos e obras"
    >
      <div className="mx-auto max-w-[1440px] px-6 md:px-10">
        <div className="mb-16 flex flex-col gap-6 md:mb-24 md:flex-row md:items-end md:justify-between">
          <div>
            <span data-rule aria-hidden="true" className="mb-5 block h-px w-10 origin-left bg-accent" />
            <p data-port-fade className="kicker mb-6">Projetos</p>
            <h2 className="font-display text-[clamp(2rem,4.6vw,4.2rem)] font-bold uppercase leading-[1.02] tracking-tight text-bone">
              <span className="block overflow-hidden">
                <span data-port-line className="block">
                  Cada obra conta{" "}
                  <em className="font-serif font-normal normal-case italic text-accent">uma história.</em>
                </span>
              </span>
            </h2>
          </div>
          <p data-port-fade className="max-w-sm text-sm leading-relaxed text-bone/60">
            Uma seleção de imagens de construção, reformas e acabamentos.
            Fotos demonstrativas — em breve, obras próprias da Do Bão.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 md:grid-cols-12 md:gap-x-8 md:gap-y-20">
          {IMAGES.gallery.map((item, i) => (
            <figure
              key={item.src}
              data-gallery-item
              className={`group relative ${LAYOUT[i] ?? ""}`}
            >
              <button
                type="button"
                onClick={() => openLightbox(i)}
                data-cursor-hover
                aria-label={`Ampliar imagem: ${item.label}`}
                className="block w-full overflow-hidden text-left outline-none"
              >
                <div className="relative overflow-hidden">
                  <div data-gallery-clip className={`${item.ratio} w-full overflow-hidden`}>
                    <span className="block h-full w-full transition-transform duration-700 ease-out group-hover:scale-[1.05]">
                      <img
                        data-gallery-img
                        src={item.src}
                        alt={`${item.label} — imagem demonstrativa de alto padrão`}
                        loading="lazy"
                        decoding="async"
                        className="h-[115%] w-full object-cover will-change-transform"
                      />
                    </span>
                  </div>
                  <div
                    aria-hidden="true"
                    className="absolute inset-0 bg-ink/0 transition-colors duration-500 group-hover:bg-ink/15"
                  />
                  <span className="absolute right-4 top-4 flex h-10 w-10 items-center justify-center bg-ink/60 text-bone opacity-0 backdrop-blur transition-all duration-500 group-hover:opacity-100">
                    <ZoomIn size={16} />
                  </span>
                </div>
                <figcaption data-gallery-cap className="mt-4 flex items-baseline justify-between">
                  <span className="text-[11px] font-semibold uppercase tracking-widest2 text-bone/70">
                    {item.label}
                  </span>
                  <span className="text-[11px] text-concrete">
                    0{i + 1} / 0{IMAGES.gallery.length}
                  </span>
                </figcaption>
              </button>
            </figure>
          ))}
        </div>
      </div>

      {current && (
        <div
          ref={overlayRef}
          role="dialog"
          aria-modal="true"
          aria-label={`Imagem ampliada: ${current.label}`}
          className="fixed inset-0 z-[70] flex items-center justify-center bg-ink/95 p-4 backdrop-blur-md md:p-12"
          onClick={closeLightbox}
        >
          <div
            ref={figRef}
            className="relative max-h-full w-full max-w-5xl"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={current.src.replace("w=900", "w=1800").replace("w=1600", "w=2000")}
              alt={`${current.label} — imagem demonstrativa ampliada`}
              className="max-h-[78vh] w-full object-contain"
            />
            <div className="mt-5 flex items-center justify-between">
              <span className="text-[11px] font-semibold uppercase tracking-widest2 text-bone/80">
                {current.label}
              </span>
              <span className="text-[11px] text-concrete">
                {String((lightbox ?? 0) + 1).padStart(2, "0")} /{" "}
                {String(IMAGES.gallery.length).padStart(2, "0")}
              </span>
            </div>
          </div>

          <button
            type="button"
            onClick={closeLightbox}
            data-cursor-hover
            autoFocus
            aria-label="Fechar visualização"
            className="absolute right-5 top-5 flex h-12 w-12 items-center justify-center border border-bone/20 text-bone transition-colors hover:border-accent hover:bg-accent"
          >
            <X size={20} />
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              step(-1);
            }}
            data-cursor-hover
            aria-label="Imagem anterior"
            className="absolute left-4 top-1/2 flex h-12 w-12 -translate-y-1/2 items-center justify-center border border-bone/20 text-bone transition-colors hover:border-accent hover:bg-accent md:left-8"
          >
            <ArrowLeft size={20} />
          </button>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              step(1);
            }}
            data-cursor-hover
            aria-label="Próxima imagem"
            className="absolute right-4 top-1/2 flex h-12 w-12 -translate-y-1/2 items-center justify-center border border-bone/20 text-bone transition-colors hover:border-accent hover:bg-accent md:right-8"
          >
            <ArrowRight size={20} />
          </button>
        </div>
      )}
    </section>
  );
}
