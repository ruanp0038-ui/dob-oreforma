import { gsap, useGsapScope } from "../lib/anim";

const ITEMS = [
  "Construção",
  "Reformas",
  "Gestão de Obras",
  "Projetos",
  "Acabamento de Alto Padrão",
];

export default function Marquee() {
  const ref = useGsapScope<HTMLDivElement>(({ reduced }) => {
    if (reduced) return;
    gsap.to("[data-marquee-track]", {
      xPercent: -50,
      ease: "none",
      duration: 30,
      repeat: -1,
    });
  });

  const Row = ({ hidden }: { hidden?: boolean }) => (
    <div aria-hidden={hidden} className="flex shrink-0 items-center">
      {ITEMS.map((item) => (
        <span key={item} className="flex items-center">
          <span className="whitespace-nowrap px-8 font-display text-[clamp(1.8rem,4.5vw,4rem)] font-extrabold uppercase tracking-tight text-bone/90">
            {item}
          </span>
          <span
            aria-hidden="true"
            className="h-2 w-2 shrink-0 rotate-45 bg-accent"
          />
        </span>
      ))}
    </div>
  );

  return (
    <div
      ref={ref}
      aria-hidden="true"
      role="presentation"
      className="relative overflow-hidden border-y border-white/5 bg-ink py-10 md:py-14"
    >
      <div data-marquee-track className="flex w-max will-change-transform">
        <Row />
        <Row hidden />
      </div>
    </div>
  );
}
