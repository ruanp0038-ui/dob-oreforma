import { gsap, liteReveal, useGsapScope } from "../lib/anim";
import { DIFFERENTIALS } from "../config/site";

const OFFSETS = [
  "",
  "md:col-start-6 md:mt-20",
  "md:col-start-2 md:mt-10",
  "md:col-start-8 md:mt-24",
  "md:col-start-4 md:mt-14",
];

export default function Differential() {
  const ref = useGsapScope<HTMLElement>(({ reduced }) => {
    if (reduced) {
      liteReveal("[data-diff-line], [data-diff-fade], [data-diff]");
      return;
    }
    gsap.fromTo(
      "[data-diff-line]",
      { yPercent: 115 },
      {
        yPercent: 0,
        duration: 1,
        ease: "power4.out",
        scrollTrigger: { trigger: "[data-diff-line]", start: "top 88%" },
      }
    );
    gsap.fromTo(
      "[data-diff-fade]",
      { opacity: 0, y: 22 },
      {
        opacity: 1,
        y: 0,
        duration: 0.8,
        ease: "power3.out",
        scrollTrigger: { trigger: "[data-diff-line]", start: "top 88%" },
      }
    );
    gsap.utils.toArray<HTMLElement>("[data-diff]").forEach((el, i) => {
      const rule = el.querySelector("[data-diff-rule]");
      if (rule) {
        gsap.fromTo(
          rule,
          { scaleX: 0 },
          {
            scaleX: 1,
            duration: 0.8,
            ease: "power3.out",
            scrollTrigger: { trigger: el, start: "top 85%" },
          }
        );
      }
      gsap.fromTo(
        el,
        { opacity: 0, y: 44 },
        {
          opacity: 1,
          y: 0,
          duration: 0.9,
          delay: (i % 2) * 0.08,
          ease: "power3.out",
          scrollTrigger: { trigger: el, start: "top 85%" },
        }
      );
    });
  });

  return (
    <section
      ref={ref}
      className="relative border-t border-white/5 bg-graphite py-24 md:py-36"
      aria-label="Diferenciais"
    >
      <div className="mx-auto max-w-[1440px] px-6 md:px-10">
        <div className="mb-16 md:mb-28">
          <span data-rule aria-hidden="true" className="mb-5 block h-px w-10 origin-left bg-accent" />
          <p data-diff-fade className="kicker mb-6">Diferencial</p>
          <h2 className="font-display text-[clamp(2rem,4.6vw,4.2rem)] font-bold uppercase leading-[1.02] tracking-tight text-bone">
            <span className="block overflow-hidden">
              <span data-diff-line className="block">
                Por que escolher{" "}
                <em className="font-serif font-normal normal-case italic text-accent">a Do Bão?</em>
              </span>
            </span>
          </h2>
        </div>

        <div className="grid grid-cols-1 gap-14 md:grid-cols-12 md:gap-y-6">
          {DIFFERENTIALS.map((item, i) => (
            <article
              key={item.num}
              data-diff
              className={`group max-w-md md:col-span-5 ${OFFSETS[i]}`}
            >
              <div className="flex items-center gap-4">
                <span className="font-display text-sm font-bold tracking-widest text-accent">
                  {item.num}
                </span>
                <span
                  data-diff-rule
                  aria-hidden="true"
                  className="h-px w-12 origin-left bg-bone/20 transition-[width,background-color] duration-500 group-hover:w-20 group-hover:bg-accent"
                />
              </div>
              <h3 className="mt-5 font-display text-xl font-bold uppercase leading-tight tracking-tight text-bone md:text-2xl">
                {item.title}
              </h3>
              <p className="mt-3 text-sm leading-relaxed text-bone/60">
                {item.desc}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
