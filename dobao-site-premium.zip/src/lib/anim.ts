import { useLayoutEffect, useRef, type RefObject } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

if (typeof window !== "undefined") {
  ScrollTrigger.config({ ignoreMobileResize: true });
}

export { gsap, ScrollTrigger };

const MOTION_KEY = "db-motion";

export function setMotionPreference(enabled: boolean) {
  try {
    localStorage.setItem(MOTION_KEY, enabled ? "full" : "lite");
  } catch {}
}

function storedMotion(): boolean | null {
  try {
    const v = localStorage.getItem(MOTION_KEY);
    return v === "full" ? true : v === "lite" ? false : null;
  } catch {
    return null;
  }
}

export function prefersReducedMotion(): boolean {
  if (typeof window === "undefined") return false;
  const stored = storedMotion();
  if (stored !== null) return !stored;
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

// Modo lite (prefers-reduced-motion): apenas fades sutis de entrada,
// sem transforms, parallax ou movimento grande.
export function liteReveal(
  targets: string,
  opts?: { start?: string; duration?: number }
) {
  gsap.utils.toArray<HTMLElement>(targets).forEach((el) => {
    gsap.fromTo(
      el,
      { autoAlpha: 0 },
      {
        autoAlpha: 1,
        duration: opts?.duration ?? 0.5,
        ease: "power1.out",
        scrollTrigger: { trigger: el, start: opts?.start ?? "top 92%" },
      }
    );
  });
}

type ScopeCallback = (ctx: { reduced: boolean }) => void;

export function useGsapScope<T extends HTMLElement = HTMLDivElement>(
  callback: ScopeCallback
): RefObject<T> {
  const ref = useRef<T>(null);

  useLayoutEffect(() => {
    const el = ref.current;
    if (!el) return;
    const reduced = prefersReducedMotion();
    const ctx = gsap.context(() => callback({ reduced }), el);
    return () => ctx.revert();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return ref;
}
