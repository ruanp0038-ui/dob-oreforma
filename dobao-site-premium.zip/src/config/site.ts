const WA_MESSAGE =
  "Olá! Vim pelo site da Do Bão Reformas & Construção e gostaria de solicitar um orçamento.";

export const WHATSAPP_LINK = `https://wa.me/5516991656398?text=${encodeURIComponent(
  WA_MESSAGE
)}`;
export const PHONE_DISPLAY = "(16) 99165-6398";
export const PHONE_HREF = "tel:+5516991656398";
export const LOCATION = "Ribeirão Preto — SP";

export const NAV_ITEMS = [
  { label: "Início", href: "#inicio" },
  { label: "Serviços", href: "#servicos" },
  { label: "Projetos", href: "#projetos" },
  { label: "Sobre", href: "#sobre" },
  { label: "Contato", href: "#contato" },
];

export const SOCIALS = [
  { label: "Instagram", href: "https://www.instagram.com/dobao_reformas_construcao/" },
  { label: "Facebook", href: "https://www.facebook.com/dobaoreformas" },
  { label: "YouTube", href: "https://www.youtube.com/channel/UCZNFYguUui0EmrqN---7xDw" },
];

const u = (id: string, w = 1600) =>
  `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=80`;

// IMAGENS DEMONSTRATIVAS — substituir pelas fotos reais da Do Bão Reformas.
export const IMAGES = {
  hero: u("1600585154340-be6161a56a0c", 2000),
  intro: u("1503387762-592deb58ef4e", 1000),
  management: u("1503387837-b154d5074bd2", 1200),
  about1: u("1541888946425-d81bb19240f5", 1000),
  about2: u("1616486338812-3dadae4b4ace", 800),
  services: [
    u("1487958449943-2429e8be8625", 900),
    u("1503387762-592deb58ef4e", 900),
    u("1503387837-b154d5074bd2", 900),
    u("1541888946425-d81bb19240f5", 900),
  ],
  gallery: [
    { src: u("1600585154340-be6161a56a0c", 1600), label: "Construção", ratio: "aspect-[4/5]" },
    { src: u("1600585152220-90363fe7e115", 900), label: "Interiores", ratio: "aspect-[4/3]" },
    { src: u("1541888946425-d81bb19240f5", 900), label: "Reformas", ratio: "aspect-square" },
    { src: u("1600566752355-35792bedcfea", 900), label: "Acabamentos", ratio: "aspect-[4/3]" },
    { src: u("1517646287270-a5a9ca602e5c", 900), label: "Design de interiores", ratio: "aspect-[3/4]" },
    { src: u("1618221195710-dd6b41faaea6", 1800), label: "Acabamento premium", ratio: "aspect-[16/9]" },
  ],
};

export const SERVICES_MAIN = [
  {
    title: "Engenharia",
    desc: "Soluções técnicas com responsabilidade, do estudo à execução da obra.",
  },
  {
    title: "Projetos",
    desc: "Planejamento e projeto da sua reforma ou construção, antes de começar.",
  },
  {
    title: "Construção",
    desc: "Sua casa planejada, projetada e construída com atenção a cada etapa.",
  },
  {
    title: "Reformas",
    desc: "Transformação de ambientes com alto padrão de acabamento.",
  },
  {
    title: "Gestão de Obras",
    desc: "Organização e acompanhamento completo, do início à entrega.",
  },
];

export const SERVICES_SPECIALIZED = [
  "Pedreiro",
  "Eletricista",
  "Encanador",
  "Gesseiro",
  "Pintura",
];

export const SERVICES_FINISHING = [
  "Alvenaria",
  "Reboco",
  "Assentamento de piso",
  "Porcelanato",
  "Reparos",
];

export const PROCESS_STEPS = [
  {
    num: "01",
    title: "Planejamento",
    desc: "Entendemos o que você precisa e organizamos cada etapa antes de começar.",
  },
  {
    num: "02",
    title: "Projeto",
    desc: "Definição de escopo, prazos e escolhas — para evitar erros e retrabalho.",
  },
  {
    num: "03",
    title: "Execução",
    desc: "Mão de obra especializada realizando a obra com técnica e cuidado.",
  },
  {
    num: "04",
    title: "Acompanhamento",
    desc: "Gestão e supervisão contínuas, mantendo a obra clara e no ritmo.",
  },
  {
    num: "05",
    title: "Entrega",
    desc: "Conclusão com atenção aos detalhes e acabamento de alto padrão.",
  },
];

export const DIFFERENTIALS = [
  {
    num: "01",
    title: "Experiência em construção e reforma",
    desc: "Especialistas dedicados a transformar casas com qualidade.",
  },
  {
    num: "02",
    title: "Gestão de obras",
    desc: "Processo organizado, do planejamento à entrega.",
  },
  {
    num: "03",
    title: "Atenção aos detalhes",
    desc: "Cada etapa revisada com cuidado, até o acabamento final.",
  },
  {
    num: "04",
    title: "Planejamento",
    desc: "Menos erros, menos riscos e um caminho mais direto ao resultado.",
  },
  {
    num: "05",
    title: "Profissionais especializados",
    desc: "Pedreiros, eletricistas, encanadores, gesseiros e pintores.",
  },
];
