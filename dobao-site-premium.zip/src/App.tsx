import Header from "./components/Header";
import Preloader from "./components/Preloader";
import Hero from "./components/Hero";
import Intro from "./components/Intro";
import Marquee from "./components/Marquee";
import Services from "./components/Services";
import Management from "./components/Management";
import Process from "./components/Process";
import Portfolio from "./components/Portfolio";
import Differential from "./components/Differential";
import About from "./components/About";
import Contact from "./components/Contact";
import Footer from "./components/Footer";
import WhatsAppFloat from "./components/WhatsAppFloat";
import Cursor from "./components/Cursor";
import ScrollProgress from "./components/ScrollProgress";
import MagneticButtons from "./components/MagneticButtons";
import EntranceFX from "./components/EntranceFX";

export default function App() {
  return (
    <>
      <a
        href="#intro"
        className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[110] focus:bg-bone focus:px-4 focus:py-2 focus:text-ink"
      >
        Pular para o conteúdo
      </a>
      <ScrollProgress />
      <MagneticButtons />
      <EntranceFX />
      <Preloader />
      <Header />
      <main>
        <Hero />
        <Intro />
        <Marquee />
        <Services />
        <Management />
        <Process />
        <Portfolio />
        <Differential />
        <About />
        <Contact />
      </main>
      <Footer />
      <WhatsAppFloat />
      <Cursor />
    </>
  );
}
